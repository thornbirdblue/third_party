:class:`~toro.Event` example - a caching proxy server
=====================================================

.. automodule:: examples.event_example

.. literalinclude:: ../../examples/event_example.py
    :start-after: # start-file
