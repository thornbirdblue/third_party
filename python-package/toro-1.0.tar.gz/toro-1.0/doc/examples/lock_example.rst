:class:`~toro.Lock` example - graceful shutdown
===============================================

.. automodule:: examples.lock_example

.. literalinclude:: ../../examples/lock_example.py
    :start-after: # start-file
