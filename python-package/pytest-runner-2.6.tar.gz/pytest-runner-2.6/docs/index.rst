Welcome to pytest-runner documentation!
=======================================

.. toctree::
   :maxdepth: 1

   history

.. include:: ../README.txt

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

